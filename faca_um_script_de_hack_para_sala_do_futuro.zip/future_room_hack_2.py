   python3 future_room_hack.py --mode sniff      # Sniffing de rede
   python3 future_room_hack.py --mode brute     # Brute-force
   python3 future_room_hack.py --mode firmware  # Exploit de firmware
